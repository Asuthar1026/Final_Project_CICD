// Import the Express library
const express = require('express');

// Create an Express application
const app = express();

// Define the `/hello` route
app.get('/hello', (req, res) => {
    res.json({ message: "Hello, World! This is my Final Project, Astha Suthar-8906626" });
});

// Start the server
const PORT = process.env.PORT || 3000; // Use the PORT environment variable if available
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
